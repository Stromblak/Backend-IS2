-- Adminer 4.8.1 MySQL 8.0.33 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `Archivos`;
CREATE TABLE `Archivos` (
  `idArc` int NOT NULL AUTO_INCREMENT,
  `idRep` int NOT NULL,
  `archivo` blob NOT NULL,
  PRIMARY KEY (`idArc`),
  KEY `idRep` (`idRep`),
  CONSTRAINT `Archivos_ibfk_2` FOREIGN KEY (`idRep`) REFERENCES `Reportes` (`idRep`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


DROP TABLE IF EXISTS `Avances`;
CREATE TABLE `Avances` (
  `comentario` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `idRep` int NOT NULL,
  `correoDev` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `idAvance` int NOT NULL AUTO_INCREMENT COMMENT 'insert automatico',
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'insert automatico',
  PRIMARY KEY (`idAvance`),
  KEY `idRep` (`idRep`),
  KEY `correoDev` (`correoDev`),
  CONSTRAINT `Avances_ibfk_3` FOREIGN KEY (`idRep`) REFERENCES `Reportes` (`idRep`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Avances_ibfk_5` FOREIGN KEY (`correoDev`) REFERENCES `Devs` (`correoDev`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Avances` (`comentario`, `idRep`, `correoDev`, `idAvance`, `fecha`) VALUES
('no encuentro el pdf',	2,	'jaina@gmail.com',	1,	'2023-05-28 02:42:09'),
('Aquí vamos',	2,	'jaina@gmail.com',	4,	'2023-06-23 09:35:04'),
('Recién comenzamos a trabajar',	13,	'arthas@gmail.com',	5,	'2023-06-23 09:56:26'),
('Le estamos poniendo empeño',	13,	'arthas@gmail.com',	6,	'2023-06-23 10:04:06'),
('Vamos chiquillos',	15,	'arthas@gmail.com',	7,	'2023-06-23 10:12:19'),
('si se puede',	15,	'arthas@gmail.com',	8,	'2023-06-23 10:12:33'),
('lololololo',	13,	'arthas@gmail.com',	9,	'2023-06-23 10:21:07'),
('Ya se acabó el semestre',	15,	'arthas@gmail.com',	10,	'2023-06-23 10:22:32'),
('No voy a terminar nunca',	13,	'arthas@gmail.com',	11,	'2023-06-25 04:57:48'),
('Yo no tengo que ver con el crasheo del pc se un usuario.',	4,	'muradin@gmail.com',	12,	'2023-06-28 17:29:23'),
('lololololololo',	3,	'muradin@gmail.com',	13,	'2023-06-28 17:58:10'),
('avance',	3,	'muradin@gmail.com',	14,	'2023-06-28 19:44:26'),
('avamce2',	3,	'muradin@gmail.com',	15,	'2023-06-28 19:44:32'),
('He revisado el bug y es correcto',	19,	'muradin@gmail.com',	16,	'2023-06-28 21:24:34');

DROP TABLE IF EXISTS `Credenciales`;
CREATE TABLE `Credenciales` (
  `correo` varchar(255) NOT NULL,
  `hash` int NOT NULL,
  `tipoUsuario` int NOT NULL COMMENT '0: dev   1: admin   2: cliente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Credenciales` (`correo`, `hash`, `tipoUsuario`) VALUES
('arthas@gmail.com',	12345,	1),
('gnomo@gmail.com',	1234,	2),
('usuario@gmail.com',	1234,	2),
('esteban@gmail.com',	3415,	1),
('hoalsd@gmail.com',	123,	0),
('jaina@gmail.com',	1234,	0),
('lolo@gmail.com',	2134,	1),
('mario@gmail.com',	9876,	1),
('muradin@gmail.com',	1234,	0),
('pepa@gmail.com',	1234,	0),
('seba@gmail.com',	3657345,	1),
('solo@num.cl',	1234,	1),
('uther@gmail.com',	1234,	0),
('zoporteteknico@gmail.com',	1234,	1),
('josejose@gmail.com',	1234,	1),
('lola@gmail.com',	987,	2);

DROP TABLE IF EXISTS `Devs`;
CREATE TABLE `Devs` (
  `nombre` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `apellido` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `carga` int NOT NULL DEFAULT '0' COMMENT 'automatico / no hacer nada con el',
  `correoDev` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `hash` int NOT NULL,
  `esAdmin` bit(1) NOT NULL DEFAULT b'0' COMMENT 'flag si es admin o no. False/True',
  PRIMARY KEY (`correoDev`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Devs` (`nombre`, `apellido`, `carga`, `correoDev`, `hash`, `esAdmin`) VALUES
('Arthas',	'Menethil',	2,	'arthas@gmail.com',	12345,	CONV('1', 2, 10) + 0),
('Esteban',	'Quito',	0,	'esteban@gmail.com',	3415,	CONV('1', 2, 10) + 0),
('pepin',	'pepon',	0,	'hoalsd@gmail.com',	123,	CONV('0', 2, 10) + 0),
('Jaina',	'Proudmore',	2,	'jaina@gmail.com',	1234,	CONV('0', 2, 10) + 0),
('Jose',	'Beltran',	0,	'josejose@gmail.com',	1234,	CONV('1', 2, 10) + 0),
('Lolo',	'Manolo',	0,	'lolo@gmail.com',	2134,	CONV('1', 2, 10) + 0),
('Mario',	'Pérez',	1,	'mario@gmail.com',	23456235,	CONV('1', 2, 10) + 0),
('Muradin',	'Bronzebeard',	2,	'muradin@gmail.com',	1234,	CONV('0', 2, 10) + 0),
('pepito',	'pagadoble',	0,	'pepa@gmail.com',	1234,	CONV('0', 2, 10) + 0),
('Sebastian',	'Aguila',	0,	'sebagmail.com',	3657345,	CONV('1', 2, 10) + 0),
('otro',	'mas',	0,	'solo@num.cl',	1234,	CONV('1', 2, 10) + 0),
('Uther',	'the Lightbringer',	1,	'uther@gmail.com',	1234,	CONV('0', 2, 10) + 0),
('Bakshi',	'Kapoor',	2,	'zoporteteknico@gmail.com',	1234,	CONV('1', 2, 10) + 0);

DELIMITER ;;

CREATE TRIGGER `Dev nuevo` AFTER INSERT ON `Devs` FOR EACH ROW
INSERT INTO Credenciales(correo, hash, tipoUsuario)
VALUES (new.correoDev, new.hash, new.esAdmin);;

CREATE TRIGGER `devs actualizacion` AFTER UPDATE ON `Devs` FOR EACH ROW
UPDATE Credenciales
SET correo = new.correoDev, hash = new.hash, tipoUsuario = new.esAdmin
WHERE correo = old.correoDev;;

CREATE TRIGGER `dev eliminado` AFTER DELETE ON `Devs` FOR EACH ROW
DELETE FROM Credenciales WHERE correo = old.correoDev;;

DELIMITER ;

DROP TABLE IF EXISTS `Reportes`;
CREATE TABLE `Reportes` (
  `software` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `titulo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `descripcion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `pasos` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci COMMENT 'puede ser nulo',
  `estado` int NOT NULL DEFAULT '0' COMMENT 'insert y asignado automatico',
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'insert automatico',
  `correo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `idRep` int NOT NULL AUTO_INCREMENT COMMENT 'insert automatico',
  PRIMARY KEY (`idRep`),
  KEY `correo` (`correo`),
  KEY `software` (`software`),
  CONSTRAINT `Reportes_ibfk_4` FOREIGN KEY (`correo`) REFERENCES `Usuarios` (`correo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `Reportes_ibfk_6` FOREIGN KEY (`software`) REFERENCES `Softwares` (`software`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Reportes` (`software`, `titulo`, `descripcion`, `pasos`, `estado`, `fecha`, `correo`, `idRep`) VALUES
('Ransomware Indio Inc.',	'0.11 bitcoins',	'nos atacaron :(',	'no cambiar la contrasena\r\n...\r\nprofit',	2,	'2023-05-28 02:25:55',	'usuario@gmail.com',	1),
('Purga.exe',	'infecto a mi computador',	'decia que era un pdf de cargamento de trigo',	'abrir el pdf',	1,	'2023-05-28 02:25:55',	'gnomo@gmail.com',	2),
('Purga.exe',	'no encuentro los iconos en el escritorio',	'los iconos desaparecieron y se me cambio el fondo de pantalla',	'',	1,	'2023-05-28 02:25:55',	'gnomo@gmail.com',	3),
('Purga.exe',	'crasheo de pc  ',	'da pantallazo al apretar el boton de cerrar',	'apretar el boton de cerrar',	2,	'2023-05-28 02:25:55',	'gnomo@gmail.com',	4),
('Minecraft 2',	'El creeper no explota',	'eso',	'',	1,	'2023-05-28 02:25:55',	'usuario@gmail.com',	5),
('Minecraft 2',	'Creeper 2 el regreso',	'Otro creeper me exploto mi casita',	'1. deje la puerta abierta\r\n2. entro sin que me diera cuenta',	1,	'2023-05-31 17:37:57',	'usuario@gmail.com',	8),
('Ransomware Indio Inc.',	'Hola en indi',	'prueba envio de reportes',	'1.prueba exitosa ',	1,	'2023-05-31 17:40:45',	'usuario@gmail.com',	9),
('Pruebafuego',	'Nuevo bug ',	'Agregacion de nuevo bug ',	'lo agregue',	2,	'2023-05-31 17:51:49',	'usuario@gmail.com',	10),
('Pruebafuego',	'hola',	'como esta ',	'oaisdioajsd',	2,	'2023-05-31 19:21:40',	'usuario@gmail.com',	11),
('ROberto',	'Hackeo masivo',	'oasidasdjoijadioajijasdjajidoiajosdj',	'1 uno 2 dos tres',	1,	'2023-06-01 01:50:39',	'usuario@gmail.com',	12),
('Purga.exe',	'Podre reportarl',	'ahora lo averiguaremos',	'me encanta el chile',	1,	'2023-06-02 02:54:24',	'usuario@gmail.com',	13),
('Pruebafuego',	'Ojala salvar is2',	'Sprint review 2',	'Hay que trabajar',	2,	'2023-06-07 19:16:06',	'usuario@gmail.com',	14),
('Purga.exe',	'HOlasd',	'como estan',	'1. hola \r\n2.dos',	0,	'2023-06-07 19:43:25',	'usuario@gmail.com',	15),
('Ransomware Indio Inc.',	'test',	'testing',	'1. Test\n2. Ing',	1,	'2023-06-09 19:45:58',	'usuario@gmail.com',	16),
('ROberto',	'No carga al iniciar sesión',	'Intento iniciar sesión y el programa se queda colgado.',	'1. Abrir el programa.\n2. Ingresar la cuenta.\n3. Dar click en ingresar',	0,	'2023-06-24 21:08:09',	'usuario@gmail.com',	17),
('Purga.exe',	'purga',	'hola',	'hola222',	0,	'2023-06-28 19:41:31',	'usuario@gmail.com',	18),
('Purga.exe',	'Problema al ingresar',	'No puedo ingresar a mi cuenta desde el login',	'1. Abrir la página\n2. Loguearse\n3. Aparece el error',	1,	'2023-06-28 21:21:41',	'usuario@gmail.com',	19);

DELIMITER ;;

CREATE TRIGGER `cambioEstadoVerdadero_asignadoA` BEFORE UPDATE ON `Reportes` FOR EACH ROW
IF NEW.estado = 2
THEN
UPDATE asignadoA as a SET a.reporteListo = True WHERE a.idRep = new.idRep;
END IF;;

DELIMITER ;

DROP TABLE IF EXISTS `Softwares`;
CREATE TABLE `Softwares` (
  `software` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`software`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Softwares` (`software`) VALUES
('Minecraft 2'),
('Pruebafuego'),
('Purga.exe'),
('Ransomware Indio Inc.'),
('ROberto');

DROP TABLE IF EXISTS `Usuarios`;
CREATE TABLE `Usuarios` (
  `correo` varchar(255) NOT NULL,
  `hash` int NOT NULL,
  PRIMARY KEY (`correo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `Usuarios` (`correo`, `hash`) VALUES
('gnomo@gmail.com',	1234),
('usuario@gmail.com',	1234);

DELIMITER ;;

CREATE TRIGGER `nuevo usuario` AFTER INSERT ON `Usuarios` FOR EACH ROW
INSERT INTO Credenciales(correo, hash, tipoUsuario)
VALUES (new.correo, new.hash, 2);;

CREATE TRIGGER `update usuario` AFTER UPDATE ON `Usuarios` FOR EACH ROW
UPDATE Credenciales
SET correo = new.correo, hash = new.hash
WHERE correo = old.correo;;

CREATE TRIGGER `usuario delete` AFTER DELETE ON `Usuarios` FOR EACH ROW
DELETE FROM Credenciales WHERE correo = old.correo;;

DELIMITER ;

DROP TABLE IF EXISTS `asignadoA`;
CREATE TABLE `asignadoA` (
  `idRep` int NOT NULL,
  `correoDev` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `reporteListo` bit(1) NOT NULL DEFAULT b'0' COMMENT 'automatico / no hacer nada con el',
  `fecha` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'insert automatico',
  KEY `idRep` (`idRep`),
  KEY `correoDev` (`correoDev`),
  CONSTRAINT `asignadoA_ibfk_7` FOREIGN KEY (`idRep`) REFERENCES `Reportes` (`idRep`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `asignadoA_ibfk_9` FOREIGN KEY (`correoDev`) REFERENCES `Devs` (`correoDev`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `asignadoA` (`idRep`, `correoDev`, `reporteListo`, `fecha`) VALUES
(2,	'jaina@gmail.com',	CONV('0', 2, 10) + 0,	'2023-05-28 02:45:35'),
(3,	'muradin@gmail.com',	CONV('0', 2, 10) + 0,	'2023-05-28 02:40:24'),
(4,	'muradin@gmail.com',	CONV('1', 2, 10) + 0,	'2023-05-28 02:18:04'),
(5,	'uther@gmail.com',	CONV('0', 2, 10) + 0,	'2023-06-01 13:13:19'),
(9,	'zoporteTeknico@gmail.com',	CONV('0', 2, 10) + 0,	'2023-06-01 21:41:03'),
(13,	'arthas@gmail.com',	CONV('0', 2, 10) + 0,	'2023-06-02 03:36:32'),
(8,	'jaina@gmail.com',	CONV('0', 2, 10) + 0,	'2023-06-02 06:21:53'),
(10,	'pepa@gmail.com',	CONV('1', 2, 10) + 0,	'2023-06-07 19:45:59'),
(12,	'mario@gmail.com',	CONV('0', 2, 10) + 0,	'2023-06-07 20:19:15'),
(14,	'pepa@gmail.com',	CONV('1', 2, 10) + 0,	'2023-06-07 20:20:11'),
(15,	'arthas@gmail.com',	CONV('0', 2, 10) + 0,	'2023-06-07 20:23:02'),
(16,	'zoporteteknico@gmail.com',	CONV('0', 2, 10) + 0,	'2023-06-10 00:51:09'),
(19,	'muradin@gmail.com',	CONV('0', 2, 10) + 0,	'2023-06-28 21:23:37');

DELIMITER ;;

CREATE TRIGGER `prevenirMultiplesAsignaciones_Temporal` BEFORE INSERT ON `asignadoA` FOR EACH ROW
IF 
(SELECT count(*) 
FROM asignadoA
WHERE idrep = new.idRep) = 1
THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Reporte ya asignado';
END IF;;

CREATE TRIGGER `prevenirAsignacionesIncorrectas` BEFORE INSERT ON `asignadoA` FOR EACH ROW
IF 
(SELECT count(*) 
FROM haDesarrollado AS hd, Reportes AS r 
WHERE hd.correoDev = new.correoDev
AND r.idRep = new.idRep
AND hd.software = r.software) = 0
THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Dev no desarrollo el software';
END IF;;

CREATE TRIGGER `nueva_carga` AFTER INSERT ON `asignadoA` FOR EACH ROW
BEGIN
UPDATE Devs SET carga = carga +1 WHERE correoDev = new.correoDev;
UPDATE Reportes SET estado = 1 WHERE idRep = new.idRep;
END;;

CREATE TRIGGER `disminucion_carga` BEFORE UPDATE ON `asignadoA` FOR EACH ROW
IF NEW.reporteListo = True
THEN
UPDATE Devs SET carga = carga - 1 WHERE correoDev = new.correoDev;
END IF;;

CREATE TRIGGER `cambio_carga` AFTER UPDATE ON `asignadoA` FOR EACH ROW
BEGIN
UPDATE Devs SET carga = carga + 1 WHERE correoDev = new.correoDev;
UPDATE Devs SET carga = carga - 1 WHERE correoDev = old.correoDev;
END;;

CREATE TRIGGER `reversion_carga_verdaderoAFalso` AFTER UPDATE ON `asignadoA` FOR EACH ROW
IF NEW.reporteListo = False AND OLD.reporteListo = True
THEN
UPDATE Devs SET carga = carga + 1 WHERE correoDev = new.correoDev;
END IF;;

CREATE TRIGGER `eliminacion_carga` AFTER DELETE ON `asignadoA` FOR EACH ROW
IF old.reporteListo = False
THEN
UPDATE Devs SET carga = carga - 1 WHERE correoDev = old.correoDev;
END IF;;

DELIMITER ;

DROP TABLE IF EXISTS `haDesarrollado`;
CREATE TABLE `haDesarrollado` (
  `software` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `correoDev` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  KEY `software` (`software`),
  KEY `correoDev` (`correoDev`),
  CONSTRAINT `haDesarrollado_ibfk_4` FOREIGN KEY (`software`) REFERENCES `Softwares` (`software`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `haDesarrollado_ibfk_6` FOREIGN KEY (`correoDev`) REFERENCES `Devs` (`correoDev`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `haDesarrollado` (`software`, `correoDev`) VALUES
('Purga.exe',	'arthas@gmail.com'),
('Purga.exe',	'uther@gmail.com'),
('Purga.exe',	'jaina@gmail.com'),
('Purga.exe',	'muradin@gmail.com'),
('Ransomware Indio Inc.',	'zoporteTeknico@gmail.com'),
('Minecraft 2',	'uther@gmail.com'),
('Minecraft 2',	'jaina@gmail.com'),
('ROberto',	'mario@gmail.com'),
('Pruebafuego',	'muradin@gmail.com'),
('Pruebafuego',	'pepa@gmail.com');

-- 2023-07-10 13:55:20
